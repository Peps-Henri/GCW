<?php

class Form
{
    public function __construct(
        public string $nome,
        public string $tel,
        public string $mail,
        public string $senha,
        public string $cpf,
        public array $valid = []
    ) {
        $this->valid = [
            "nome" => $this->nome,
            "tel" => $this->tel,
            "mail" => $this->mail,
            "senha" => $this->senha,
            "cpf" => $this->cpf,
        ];
    }

    public function valid_vars() : array
    {
        foreach ($this->valid as $key => $value) {
            if (empty($value)) {
                die("O campo '$key' está vazio. Por favor, preencha todos os campos.");
            }
        }
        return $this->valid;
    }

    public function echos() : void
    {
        $valid = $this->valid_vars();
        foreach ($valid as $key => $value) {
            echo "$key: $value<br>";
        }
    }
}

// Receber dados via POST (exemplo)
$fgasdfa = new Form(
    $_POST["nome"] ?? '',
    $_POST["telefone"] ?? '',
    $_POST["email"] ?? '',
    $_POST["senha"] ?? '',
    $_POST["cpf"] ?? ''
);

$fgasdfa->echos();

?>
