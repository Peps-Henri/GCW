<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro</title>
    <link rel="stylesheet" href="CSS/style.css">
</head>
<body>
    <div class="form-container">
        <h2>Cadastro</h2>
        <form action="form.php" method="POST">
            <label for="nome">Nome Completo:</label>
            <input type="text" name="nome" id="nome" required><br>

            <label for="cpf">CPF:</label>
            <input type="text" name="cpf" id="cpf" required><br>

            <label for="telefone">Celular:</label>
            <input type="text" name="telefone" id="telefone" required><br>

            <label for="email">Email:</label>
            <input type="email" name="email" id="email" required><br>

            <label for="senha">Senha:</label>
            <input type="password" name="senha" id="senha" required><br>

            <input type="submit" value="Enviar">
        </form>
    </div>
</body>
</html>
